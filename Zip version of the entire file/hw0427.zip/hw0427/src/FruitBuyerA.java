public class FruitBuyerA {
    int myMoney = 10000;
    int numOfApple = 2;

    public void showBuyResult() {
        System.out.println("과일 구매자");
        System.out.println("사과 개수: " + numOfApple + "개");
        System.out.println("보유 금액: " + myMoney + "원");
    }
}
